<?php

namespace Tests\Feature;

use App\Models\Notification;
use App\Models\Project;
use App\Models\ProjectInvitation;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Auth;
use Tests\TestCase;

class CollaborationApiTest extends TestCase
{
    use RefreshDatabase;

    public function test_owner_can_invite_a_registered_user_and_the_intended_user_can_accept(): void
    {
        $owner = User::factory()->create();
        $invitee = User::factory()->create(['email' => 'invitee@example.test']);
        $project = Project::factory()->for($owner)->create();
        $ownerToken = $owner->createToken('test')->plainTextToken;
        $inviteeToken = $invitee->createToken('test')->plainTextToken;

        $create = $this->withToken($ownerToken)
            ->postJson("/api/projects/{$project->id}/invitations", ['email' => $invitee->email])
            ->assertCreated()
            ->assertJsonMissingPath('invitation.token');

        $invitationId = $create->json('invitation.id');

        Auth::forgetGuards();
        $this->withToken($inviteeToken)
            ->getJson('/api/invitations')
            ->assertOk()
            ->assertJsonPath('invitations.0.id', $invitationId);

        $this->withToken($inviteeToken)
            ->postJson("/api/invitations/{$invitationId}/accept")
            ->assertOk();

        $this->withToken($inviteeToken)
            ->getJson("/api/projects/{$project->id}/members")
            ->assertOk()
            ->assertJsonFragment(['email' => $invitee->email, 'role' => 'member']);
    }

    public function test_duplicate_pending_invites_and_self_invites_are_rejected(): void
    {
        $owner = User::factory()->create();
        $invitee = User::factory()->create();
        $project = Project::factory()->for($owner)->create();
        $token = $owner->createToken('test')->plainTextToken;

        $this->withToken($token)->postJson("/api/projects/{$project->id}/invitations", ['email' => $owner->email])->assertUnprocessable();
        $this->withToken($token)->postJson("/api/projects/{$project->id}/invitations", ['email' => $invitee->email])->assertCreated();
        $this->withToken($token)->postJson("/api/projects/{$project->id}/invitations", ['email' => $invitee->email])->assertUnprocessable();
    }

    public function test_wrong_user_and_expired_invitation_cannot_accept(): void
    {
        $owner = User::factory()->create();
        $invitee = User::factory()->create();
        $wrongUser = User::factory()->create();
        $project = Project::factory()->for($owner)->create();
        $invitation = ProjectInvitation::factory()->create([
            'project_id' => $project->id,
            'inviter_id' => $owner->id,
            'invitee_email' => $invitee->email,
            'expires_at' => now()->addDay(),
        ]);

        $this->withToken($wrongUser->createToken('test')->plainTextToken)
            ->postJson("/api/invitations/{$invitation->id}/accept")
            ->assertNotFound();

        $invitation->update(['expires_at' => now()->subMinute()]);
        Auth::forgetGuards();
        $this->withToken($invitee->createToken('test')->plainTextToken)
            ->postJson("/api/invitations/{$invitation->id}/accept")
            ->assertUnprocessable();
    }

    public function test_owner_can_manage_members_but_cannot_remove_themselves(): void
    {
        $owner = User::factory()->create();
        $member = User::factory()->create();
        $project = Project::factory()->for($owner)->create();
        $project->members()->attach($member->id, ['role' => 'member']);
        $token = $owner->createToken('test')->plainTextToken;

        $this->withToken($token)->patchJson("/api/projects/{$project->id}/members/{$member->id}", ['role' => 'manager'])->assertOk();
        $this->withToken($token)->deleteJson("/api/projects/{$project->id}/members/{$member->id}")->assertOk();
        $this->withToken($token)->deleteJson("/api/projects/{$project->id}/members/{$owner->id}")->assertUnprocessable();
    }

    public function test_task_assignment_requires_a_project_member(): void
    {
        $owner = User::factory()->create();
        $unrelated = User::factory()->create();
        $project = Project::factory()->for($owner)->create();
        $token = $owner->createToken('test')->plainTextToken;
        $payload = [
            'project_id' => $project->id,
            'assigned_to' => $unrelated->id,
            'title' => 'Restricted task',
            'status' => 'todo',
            'priority' => 'medium',
        ];

        $this->withToken($token)->postJson('/api/tasks', $payload)->assertUnprocessable();

        $project->members()->attach($unrelated->id, ['role' => 'member']);
        $this->withToken($token)->postJson('/api/tasks', $payload)->assertCreated()->assertJsonPath('task.assignee.id', $unrelated->id);
    }

    public function test_invitation_notifications_are_private_and_can_be_marked_read(): void
    {
        $owner = User::factory()->create();
        $invitee = User::factory()->create(['email' => 'notify@example.test']);
        $otherUser = User::factory()->create();
        $project = Project::factory()->for($owner)->create();
        $ownerToken = $owner->createToken('test')->plainTextToken;
        $inviteeToken = $invitee->createToken('test')->plainTextToken;

        $created = $this->withToken($ownerToken)
            ->postJson("/api/projects/{$project->id}/invitations", ['email' => $invitee->email])
            ->assertCreated();
        $notificationId = Notification::query()->firstOrFail()->id;

        Auth::forgetGuards();
        $this->withToken($inviteeToken)
            ->getJson('/api/notifications')
            ->assertOk()
            ->assertJsonPath('unread_count', 1)
            ->assertJsonPath('notifications.0.invitation.id', $created->json('invitation.id'));

        Auth::forgetGuards();
        $this->withToken($otherUser->createToken('test')->plainTextToken)
            ->patchJson("/api/notifications/{$notificationId}/read")
            ->assertNotFound();

        Auth::forgetGuards();
        $this->withToken($inviteeToken)
            ->patchJson("/api/notifications/{$notificationId}/read")
            ->assertOk();

        $this->withToken($inviteeToken)
            ->getJson('/api/notifications/unread-count')
            ->assertOk()
            ->assertJsonPath('unread_count', 0);
    }

    public function test_accepting_an_invitation_marks_its_notification_read(): void
    {
        $owner = User::factory()->create();
        $invitee = User::factory()->create();
        $project = Project::factory()->for($owner)->create();
        $invitation = ProjectInvitation::factory()->create([
            'project_id' => $project->id,
            'inviter_id' => $owner->id,
            'invitee_email' => $invitee->email,
        ]);
        $notification = Notification::create([
            'user_id' => $invitee->id,
            'project_invitation_id' => $invitation->id,
            'type' => 'project_invitation',
            'title' => 'New project invitation',
            'message' => 'You have been invited.',
        ]);

        $this->withToken($invitee->createToken('test')->plainTextToken)
            ->postJson("/api/invitations/{$invitation->id}/accept")
            ->assertOk();

        $this->assertNotNull($notification->fresh()->read_at);
    }
}
