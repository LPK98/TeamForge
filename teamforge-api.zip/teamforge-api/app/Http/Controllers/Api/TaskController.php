<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Project;
use App\Models\Task;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class TaskController extends Controller
{
    private const STATUSES = ['todo', 'in_progress', 'completed'];

    private const PRIORITIES = ['low', 'medium', 'high', 'urgent'];

    public function index(Request $request): JsonResponse
    {
        $filters = $request->validate([
            'project_id' => ['nullable', 'integer', 'exists:projects,id'],
            'status' => ['nullable', Rule::in(self::STATUSES)],
            'priority' => ['nullable', Rule::in(self::PRIORITIES)],
        ]);

        $query = Task::query()
            ->whereHas('project', fn ($projectQuery) => $this->accessibleProjectQuery($projectQuery, $request->user()->id))
            ->with(['project:id,name', 'assignee:id,name,email'])
            ->latest();

        if (isset($filters['project_id'])) {
            $query->where('project_id', $filters['project_id']);
        }

        if (isset($filters['status'])) {
            $query->where('status', $filters['status']);
        }

        if (isset($filters['priority'])) {
            $query->where('priority', $filters['priority']);
        }

        return response()->json([
            'tasks' => $query->get(),
        ]);
    }

    public function show(Request $request, int $task): JsonResponse
    {
        return response()->json([
            'task' => $this->ownedTask($request, $task)->load('project:id,name'),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $this->validatedData($request);
        $project = $this->accessibleProject($request, $validated['project_id']);
        $this->authorizeAssignment($request, $project, $validated['assigned_to'] ?? null);
        $task = $project->tasks()->create($validated);

        return response()->json([
            'message' => 'Task created successfully.',
            'task' => $task->load(['project:id,name', 'assignee:id,name,email']),
        ], 201);
    }

    public function update(Request $request, int $task): JsonResponse
    {
        $ownedTask = $this->ownedTask($request, $task);
        $validated = $this->validatedData($request);
        $project = $this->accessibleProject($request, $validated['project_id']);
        $this->authorizeAssignment($request, $project, $validated['assigned_to'] ?? null);
        $ownedTask->update($validated);

        return response()->json([
            'message' => 'Task updated successfully.',
            'task' => $ownedTask->refresh()->load(['project:id,name', 'assignee:id,name,email']),
        ]);
    }

    public function destroy(Request $request, int $task): JsonResponse
    {
        $this->ownedTask($request, $task)->delete();

        return response()->json([
            'message' => 'Task deleted successfully.',
        ]);
    }

    private function ownedTask(Request $request, int $task): Task
    {
        return Task::query()
            ->whereKey($task)
            ->whereHas('project', fn ($projectQuery) => $this->accessibleProjectQuery($projectQuery, $request->user()->id))
            ->firstOrFail();
    }

    /**
     * @return array<string, mixed>
     */
    private function validatedData(Request $request): array
    {
        return $request->validate([
            'project_id' => ['required', 'integer', 'exists:projects,id'],
            'assigned_to' => ['nullable', 'integer', 'exists:users,id'],
            'title' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:5000'],
            'status' => ['required', Rule::in(self::STATUSES)],
            'priority' => ['required', Rule::in(self::PRIORITIES)],
            'due_date' => ['nullable', 'date'],
        ]);
    }

    private function accessibleProject(Request $request, int $project): Project
    {
        return Project::query()
            ->whereKey($project)
            ->where(fn ($query) => $this->accessibleProjectQuery($query, $request->user()->id))
            ->firstOrFail();
    }

    private function accessibleProjectQuery($query, int $userId)
    {
        return $query->where('user_id', $userId)
            ->orWhereHas('members', fn ($members) => $members->whereKey($userId));
    }

    private function authorizeAssignment(Request $request, Project $project, ?int $assignedTo): void
    {
        if ($assignedTo === null) {
            return;
        }

        abort_unless($project->members()->whereKey($assignedTo)->exists() || $project->user_id === $assignedTo, 422, 'The assignee must be a member of the project.');
        $role = $project->roleFor($request->user());
        abort_unless(
            in_array($role, ['owner', 'manager'], true)
                || ($role === 'member' && $assignedTo === $request->user()->id),
            403,
            'Only project managers can assign tasks.'
        );
    }
}
